module.exports = 'Documentación de integración de assets'
